<?php

return [
    'site_title' => 'Movies',
];
