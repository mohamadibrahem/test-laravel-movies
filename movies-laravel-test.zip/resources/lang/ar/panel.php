<?php

return [
    'site_title' => 'Accounting System',
];
